package com.hsbc.codefury.errorKnights.app.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hsbc.codefury.errorKnights.app.entity.Account;
import com.hsbc.codefury.errorKnights.app.entity.Customer;
import com.hsbc.codefury.errorKnights.app.entity.Transaction;
import com.hsbc.codefury.errorKnights.app.exceptions.AccountNotFoundException;
import com.hsbc.codefury.errorKnights.app.exceptions.TransactionFailedException;

public class CustomerDaoImpl implements CustomerDao {

	List<Account> accList = new ArrayList<>();

	@Override
	public String accountRequest(String custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String customerRegister(Customer cust) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String customerLogin(String uname, String pwd) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String viewProfile(String custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean doTransaction(String senderAccId, String receiverAccId, double amount) {
		Iterator<Account> itr = accList.iterator();
		Account sender = null, receiver = null;
		try {
			while (itr.hasNext()) {
				if (sender.getAccId().equals(senderAccId)) {
					sender.setAccId(senderAccId);
				} else if (receiver.getAccId().equals(receiverAccId)) {
					receiver.setAccId(receiverAccId);
				}
			}
			if (sender == null || receiver == null) {
				throw new AccountNotFoundException();
			}

			boolean success = false;

			sender.setBalance(sender.getBalance() - amount); 		//check balance
			receiver.setBalance(receiver.getBalance() + amount);
			success = true;
			if (success) {
				throw new TransactionFailedException();
			}
			return true;

		} catch (AccountNotFoundException e1) {
			throw e1;
		}

		catch (TransactionFailedException e2) {
			throw e2;
		}
	}

	@Override
	public List<Transaction> viewTransactions(String accId) {
		List<Transaction> transList = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			conn = DriverManager.getConnection("jdbc:derby://localhost:1527/bankdb");
			if(conn != null) {
				System.out.println("Got the connection");
			}
			
			//Check if account number present in Account table
			pst = conn.prepareStatement("select * from account where account_id=?");
			pst.setString(1, accId);
			ResultSet rs = pst.executeQuery();
			
			if(rs.next() == false) {
				throw new AccountNotFoundException();
			}
			
			pst = conn.prepareStatement("select * from Transactions where account_id=?");
			pst.setString(1, accId);
			ResultSet rs1 = pst.executeQuery();
			
			while(rs1.next()) {
				Transaction t = new Transaction(rs1.getLong(1), rs1.getLong(2), rs1.getDouble(3), rs1.getString(4), rs1.getString(5), rs1.getString(6));
				transList.add(t);
			}
		}
		catch(ClassNotFoundException e) {
			System.out.println("Driver could not be found.");
		}
		catch(SQLException e) {
			System.out.println("Exception " + e);
		}
		catch(AccountNotFoundException e) {
			System.out.println(e);
		}
		return transList;
	}
}
