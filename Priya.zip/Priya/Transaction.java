package com.hsbc.codefury.errorKnights.app.entity;

public class Transaction {
	long transId; // 12 digit
	long accId;
	double amount;
	String timeStamp;
	String transType; // credit/debit
	String remarks; // status

	public Transaction() {
	}

	public Transaction(long transId, long accId, double amount, String timeStamp, String transType,
			String remarks) {
		this.transId = transId;
		this.accId = accId;
		this.amount = amount;
		this.timeStamp = timeStamp;
		this.transType = transType;
		this.remarks = remarks;
	}

	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public long getAccId() {
		return accId;
	}

	public void setAccId(long accId) {
		this.accId = accId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "transId=" + transId + ", accId=" + accId + ", amount=" + amount + ", timeStamp=" + timeStamp
				+ ", transType=" + transType + ", remarks=" + remarks;
	}

}
